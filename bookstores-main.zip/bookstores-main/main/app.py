from flask import Flask, render_template, request, jsonify
app = Flask(__name__)

from pymongo import MongoClient
client = MongoClient('mongodb://test:test@52.78.10.167', 27017)
db = client.dbsparta

@app.route('/search')
def main():
    return render_template("search.html")

@app.route('/search', methods=['GET'])
def search():
    sigun_name_receive = request.args.get('sigun_name_give')
    return jsonify({'sigun_name': sigun_name_receive})

@app.route('/list/sigun_name_give=<sigun_name>')
def listing(sigun_name):
    return render_template("list.html", sigun_name=sigun_name)

@app.route('/list/', methods=['GET'])
def show_list():
    sigun_name_receive = request.args.get('sigun_name_give')
    stores = list(db.gyeongibooks.find({'SIGUN_NM':sigun_name_receive},{'_id': False}))
    return jsonify({'stores': stores})


if __name__ == '__main__':
    app.run('0.0.0.0', port=5000, debug=True)

