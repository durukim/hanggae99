from flask import Flask, render_template, request, flash, session, redirect

app = Flask(__name__)

from pymongo import MongoClient

client = MongoClient('localhost', 27017)
db = client.dbhanghae99

@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'GET':
        return render_template('login.html')
    else:
        userid = request.form['User-id']
        password = request.form['User-pw']
        users = db.hht1users.find_one({'user_id': userid, 'user_pw': password})
        if users is None:
            flash("아이디와 비밀번호를 확인해주세요.")
        else:
            session['user'] = userid
            return redirect('main')
        return redirect('/')


if __name__ == '__main__':
    app.run('0.0.0.0', port=5000, debug=True)
